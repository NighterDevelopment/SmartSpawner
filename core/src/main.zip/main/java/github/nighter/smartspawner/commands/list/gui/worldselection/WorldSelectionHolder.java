package github.nighter.smartspawner.commands.list.gui.worldselection;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class WorldSelectionHolder implements InventoryHolder {
    @Override
    public Inventory getInventory() {
        return null;
    }
}
