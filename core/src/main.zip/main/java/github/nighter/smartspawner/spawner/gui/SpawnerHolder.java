package github.nighter.smartspawner.spawner.gui;

import github.nighter.smartspawner.spawner.properties.SpawnerData;

public interface SpawnerHolder {
    SpawnerData getSpawnerData();
}
