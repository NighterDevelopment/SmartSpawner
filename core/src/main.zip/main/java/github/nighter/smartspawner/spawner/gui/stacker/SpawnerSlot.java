package github.nighter.smartspawner.spawner.gui.stacker;

public class SpawnerSlot {
    final int slotIndex;
    final int amount;

    SpawnerSlot(int slotIndex, int amount) {
        this.slotIndex = slotIndex;
        this.amount = amount;
    }
}